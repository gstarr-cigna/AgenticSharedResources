---
name: patient-portal
description: Patient Portal project patterns and best practices. Ruby on Rails 5.2.8.1 + React 17 + TypeScript hybrid application. Synthesized from codebase patterns, implementation style, and conventions.
---

# Patient Portal — Code Patterns & Best Practices

## Tech stack

| Layer | Technology | Version |
|-------|------------|---------|
| Backend | Rails | 5.2.8.1 |
| Backend | Ruby | 2.7.4 |
| Frontend | React | 17.0.2 |
| Language | TypeScript | 4.3.2 |
| Styling | styled-components | 5.1.0 |
| UI Library | @material-ui/core | 1.5.1 |
| Forms | react-final-form | 6.5.2 |
| Testing | Jest / RSpec | 22.4.3 / - |
| Bundling | Webpacker | 5.4.3 |

## Code conventions

### General
- Single quotes in JS/TS, double quotes in Ruby
- No comments unless explicitly requested
- Prefer named exports
- Use `.jsx` for JS-only React, `.tsx` for TypeScript

### TypeScript
- `any` is allowed (`noImplicitAny: false` in tsconfig)
- Interface over type for object shapes
- Prefer `FunctionComponent<Props>` for components
- These rules are disabled: explicit-function-return-type, explicit-member-accessibility

### File extensions
- `.jsx` — JavaScript-only React components
- `.tsx` — TypeScript React components
- `.js` — JavaScript utilities/services
- `.ts` — TypeScript utilities

## React patterns

### Functional components with hooks
```typescript
import { FunctionComponent } from 'react';

interface Props {
  title: string;
  onSubmit(values: any): void;
}

const MyComponent: FunctionComponent<Props> = ({ title, onSubmit }) => {
  return <div>{title}</div>;
};

export default MyComponent;
```

### Multiple root elements with Fragment
```typescript
import { Fragment } from 'react';

return (
  <Fragment>
    <ComponentA />
    <ComponentB />
  </Fragment>
);
```

### Context API for global state
Location: `app/javascript/components/[Feature]/context/`

```typescript
import { createContext } from 'react';

interface State {
  isLoading: boolean;
  data: any;
}

const Context = createContext<State | null>(null);

export const Provider: FunctionComponent<{ children: ReactNode }> = ({ children }) => {
  const [state, setState] = useState<State>({ isLoading: false, data: null });
  
  return (
    <Context.Provider value={[state, setState]}>
      {children}
    </Context.Provider>
  );
};

export const useMyContext = () => {
  const context = useContext(Context);
  if (!context) {
    throw new Error('useMyContext must be used within Provider');
  }
  return context;
};
```

### Custom hooks for reusable behavior
Location: `app/javascript/components/hooks/`

```typescript
export const useHookName = () => {
  const [state, setState] = useState('');
  
  const handler = () => { /* ... */ };
  
  return { state, handler };
};
```

### Form state with react-final-form
```typescript
import { Form, Field } from 'react-final-form';
import { required, composeValidators } from '../../utils/validations';

<Form
  onSubmit={onSubmit}
  render={({ handleSubmit, submitting, valid }) => (
    <form onSubmit={handleSubmit}>
      <Field
        name="email"
        validate={composeValidators(required, email)}
        component={StyledInput}
      />
      <Button type="submit" disabled={submitting || !valid}>
        Submit
      </Button>
    </form>
  )}
/>
```

## API layer

### Async API functions pattern
Location: `app/javascript/api/`

```typescript
import { checkStatus, apiFetch } from '../utils/api';

interface Response {
  success: boolean;
  errors: string[] | null;
}

const myApiCallAsync = async (values: SomeType): Promise<Response> => {
  try {
    const response = await apiFetch('/endpoint', {
      method: 'PUT',
      body: JSON.stringify({ data: values }),
    });

    await checkStatus(response);

    return { success: true, errors: null };
  } catch (error) {
    const { response } = error;
    if (response?.status === 422) {
      const { errors } = await response.json();
      return { success: false, errors };
    }

    return { success: false, errors: ['Error message'] };
  }
};

export default myApiCallAsync;
```

### Service class pattern
Location: `app/javascript/services/ApiService.js`

- Handles HTTP requests with fetch
- Manages CSRF tokens from `<meta name="csrf-token">`
- Provides loading state management
- Handles error responses (401, 404, 500)

## Styling

### styled-components with theme
```typescript
import styled from 'styled-components';

export const StyledContainer = styled.div`
  margin-bottom: ${({ theme }) => theme.space.sm}px;
  
  &:focus {
    box-shadow: ${stylesUtils.focusBoxShadowBorder} !important;
  }
`;
```

### Using mdlkit design system
```typescript
import { Button, InputField, SelectField, Text, Flex } from '@BreakthroughBehavioralInc/mdlkit';
```

### Themed spacing (theme.space)
- `xs`: 4px
- `sm`: 8px
- `md`: 16px
- `lg`: 24px
- `xl`: 32px

## File organization

```
app/javascript/
├── api/                    # Async API functions (updateXxxAsync.ts)
├── components/            # React components
│   ├── hooks/            # Custom hooks (useXxx.tsx)
│   ├── shared/           # Shared UI components
│   │   ├── ui/          # Reusable UI elements
│   │   └── context/     # Shared contexts
│   └── [Feature]/       # Feature-specific components
│       └── context/     # Feature-specific contexts
├── services/             # Service classes (ApiService.js)
├── utils/               # Utilities
│   ├── api.ts          # API utilities (apiFetch, checkStatus)
│   ├── validations.ts  # Form validators
│   └── composeValidators.ts
├── translations/       # i18n translations
├── types/              # TypeScript type definitions
└── packs/              # Webpack entry points
```

## Testing patterns

### Jest tests
Location: Same directory as source, e.g., `utils.spec.tsx`

```typescript
import { functionName } from './utils';

describe('utils', () => {
  it('should do something', () => {
    expect(functionName(input)).toEqual(expected);
  });
});
```

### RSpec tests
Location: `spec/`

```ruby
RSpec.describe SomeController do
  describe '#action' do
    it 'does something' do
      get :action
      expect(response).to be_success
    end
  end
end
```

## Validation utilities

### Available validators
Location: `app/javascript/utils/validations.ts`

- `required` — field required
- `email` — valid email format
- `phone` — valid phone number
- `zipCode` — valid ZIP code
- `maxLength(n)` — max character length
- `composeValidators(...validators)` — combine multiple validators

### Usage
```typescript
import { required, composeValidators, maxLength } from '../../utils/validations';

validate={composeValidators(required, maxLength(200))}
```

## Authentication

- CSRF token from `<meta name="csrf-token">` in HTML head
- JWT tokens for API authentication
- Credentials: `same-origin` in fetch config

## Automated checks

### Lint
```bash
yarn lint
```

### Test
```bash
yarn test
```

### CI (lint + test)
```bash
npm run ci
```

### Type check
```bash
npx tsc --noEmit
```

## ESLint configuration

Key rules (from `.eslintrc.json`):
- `@typescript-eslint/explicit-function-return-type`: off
- `@typescript-eslint/explicit-member-accessibility`: error (no-public only)
- `@typescript-eslint/no-explicit-any`: off
- `react/jsx-filename-extension`: allow .jsx and .tsx
- `react/prop-types`: warn
- `import/extensions`: off

## Prettier configuration

- Single quotes in JS/TS
- Trailing commas: es5
- Arrow parens: always
- Tab width: 2

## Common patterns

### Error handling in components
```typescript
const [errors, setErrors] = useState<string[] | null>(null);

const onSubmit = async (values) => {
  const response = await apiCall(values);
  
  if (response.success) {
    onSuccess(values);
  } else if (response.errors) {
    setErrors(response.errors);
  }
};
```

### useEffect cleanup
```typescript
useEffect(() => {
  const timeoutId = setTimeout(() => {
    setState(newValue);
  }, 300);
  return () => clearTimeout(timeoutId);
}, [dependency]);
```

### Context with state updater
```typescript
const [state, setState] = useContext(MyContext);

const update = () => {
  setState(prevState => ({ ...prevState, key: value }));
};
```

## Out of bounds

- Never modify `node_modules`
- Never commit secrets to repository
- Don't bypass linting
- Don't modify vendor/bundle directories